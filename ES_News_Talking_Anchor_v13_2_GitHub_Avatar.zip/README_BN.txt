ES NEWS Talking Anchor v13.2

এই সংস্করণে v13.1 অ্যাপের UI ও Android Bengali TTS রাখা হয়েছে। 3D GLB মডেলের জন্য Three.js import map ঠিক করা হয়েছে; আগের blank 3D viewport-এর একটি সম্ভাব্য মূল কারণ ছিল GLTFLoader-এর bare module import resolve না হওয়া।

মুখের animation: GLB-তে থাকা নামযুক্ত ARKit/viseme morph targets দিয়ে blink ও পরীক্ষামূলক talking animation। এটি এখনো audio-synced Bengali phoneme lip-sync নয়। GLB-তে embedded body animation clip নেই।

Build: GitHub repository-র main branch-এ এই ZIP-এর ভেতরের ফাইলগুলো upload/replace করুন। তারপর Actions > Build ES NEWS Android APK > Run workflow। সফল হলে ES-NEWS-3D-Anchor-APK-v13.2 artifact download করুন। Android Studio লাগবে না।

প্রথমবার Three.js CDN থেকে load করার জন্য internet প্রয়োজন।
