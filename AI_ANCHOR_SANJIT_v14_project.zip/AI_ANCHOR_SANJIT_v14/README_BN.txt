AI ANCHOR SANJIT v14 starter Android project

আপনার PixVerse হাঁটা অ্যাঙ্কার ভিডিওটি standing_anchor.mp4 নামে রাখুন:
app/src/main/assets/videos/standing_anchor.mp4

এই প্রথম সংস্করণে বাংলা Android TTS, Pitch/Speed, স্ক্রিপ্ট ইনপুট,
Play/Stop এবং লুপ হওয়া অ্যাঙ্কার ভিডিও আছে।

MP4 ভিডিওটি এই ZIP-এ নেই; ব্যবহারকারীর নিজের ভিডিও যোগ করতে হবে।
এই সংস্করণে স্বয়ংক্রিয় lip-sync বা MP4 export নেই।
