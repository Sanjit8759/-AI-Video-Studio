package com.aianchorsanjit.app

import android.app.Activity
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.*
import android.graphics.Color
import android.net.Uri
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var video: VideoView
    private lateinit var script: EditText
    private lateinit var status: TextView
    private lateinit var pitchLabel: TextView
    private lateinit var speedLabel: TextView
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pitchValue = 1.0f
    private var speedValue = 1.0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildScreen()
        playAnchorVideo()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 18, 16, 16)
            setBackgroundColor(Color.rgb(7, 17, 32))
        }
        root.addView(TextView(this).apply {
            text = "AI ANCHOR SANJIT"
            textSize = 27f
            setTextColor(Color.rgb(245, 198, 85))
            gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
        }, LinearLayout.LayoutParams(-1, -2))
        root.addView(TextView(this).apply {
            text = "POWERED BY ES NEWS"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 10)
        })
        video = VideoView(this).apply { setBackgroundColor(Color.BLACK) }
        root.addView(video, LinearLayout.LayoutParams(-1, 0, 1.1f))
        status = TextView(this).apply {
            text = "স্টুডিও প্রস্তুত"
            textSize = 14f
            setTextColor(Color.rgb(245, 198, 85))
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 8)
        }
        root.addView(status)
        root.addView(TextView(this).apply {
            text = "বাংলা নিউজ স্ক্রিপ্ট লিখুন"
            textSize = 19f
            setTextColor(Color.WHITE)
        })
        script = EditText(this).apply {
            hint = "এখানে খবরের স্ক্রিপ্ট লিখুন বা পেস্ট করুন..."
            textSize = 17f
            minLines = 4
            gravity = Gravity.TOP or Gravity.START
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            setPadding(12, 12, 12, 12)
            setBackgroundColor(Color.rgb(35, 49, 68))
        }
        root.addView(script, LinearLayout.LayoutParams(-1, 0, 0.8f))
        pitchLabel = label("কণ্ঠের Pitch: 1.00")
        root.addView(pitchLabel)
        root.addView(SeekBar(this).apply {
            max = 150; progress = 50
            setOnSeekBarChangeListener(listener { v ->
                pitchValue = 0.5f + v / 100f
                pitchLabel.text = "কণ্ঠের Pitch: %.2f".format(pitchValue)
            })
        })
        speedLabel = label("কথার গতি: 1.00")
        root.addView(speedLabel)
        root.addView(SeekBar(this).apply {
            max = 150; progress = 50
            setOnSeekBarChangeListener(listener { v ->
                speedValue = 0.5f + v / 100f
                speedLabel.text = "কথার গতি: %.2f".format(speedValue)
            })
        })
        root.addView(Button(this).apply {
            text = "▶ বাংলা ভয়েসে খবর পড়ুন"
            setOnClickListener { speakNews() }
        }, LinearLayout.LayoutParams(-1, -2))
        root.addView(Button(this).apply {
            text = "■ ভয়েস বন্ধ করুন"
            setOnClickListener { tts?.stop(); status.text = "ভয়েস বন্ধ" }
        }, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    private fun label(s: String) = TextView(this).apply {
        text = s; textSize = 16f; setTextColor(Color.WHITE); setPadding(0, 8, 0, 2)
    }
    private fun listener(update: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(bar: SeekBar?, value: Int, fromUser: Boolean) = update(value)
        override fun onStartTrackingTouch(bar: SeekBar?) {}
        override fun onStopTrackingTouch(bar: SeekBar?) {}
    }

    private fun playAnchorVideo() {
        val uri = Uri.parse("file:///android_asset/videos/standing_anchor.mp4")
        video.setVideoURI(uri)
        video.setOnPreparedListener { mp ->
            mp.isLooping = true
            video.start()
            status.text = "ES NEWS অ্যাঙ্কার প্রস্তুত"
        }
        video.setOnErrorListener { _, _, _ ->
            status.text = "ভিডিও নেই: assets/videos/standing_anchor.mp4 যোগ করুন"
            true
        }
    }

    private fun speakNews() {
        val text = script.text.toString().trim()
        if (text.isEmpty()) { status.text = "আগে বাংলা নিউজ স্ক্রিপ্ট লিখুন"; return }
        if (!ttsReady) { status.text = "বাংলা ভয়েস প্রস্তুত হচ্ছে"; return }
        tts?.setPitch(pitchValue)
        tts?.setSpeechRate(speedValue)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ES_NEWS_SCRIPT")
        status.text = "অ্যাঙ্কার নিউজ পড়ছে"
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) {
            val r = tts?.setLanguage(Locale("bn", "IN"))
            ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
            runOnUiThread { if (::status.isInitialized) status.text =
                if (ttsReady) "বাংলা ভয়েস প্রস্তুত" else "ফোনে বাংলা TTS ভয়েস নেই" }
        }
    }
    override fun onDestroy() {
        tts?.stop(); tts?.shutdown()
        super.onDestroy()
    }
}
