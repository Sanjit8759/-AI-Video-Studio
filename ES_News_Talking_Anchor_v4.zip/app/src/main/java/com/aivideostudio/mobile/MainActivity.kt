package com.aivideostudio.mobile

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ready = false
    private lateinit var script: EditText
    private lateinit var status: TextView
    private lateinit var avatar: AnchorView
    private lateinit var genderPicker: Spinner

    private fun rounded(color: Int, radius: Float = 14f) =
        GradientDrawable().apply { setColor(color); cornerRadius = radius }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 18, 16, 22)
            setBackgroundColor(Color.rgb(9, 17, 31))
        }
        val scroll = ScrollView(this).apply { addView(root) }

        fun label(value: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) =
            TextView(this).apply {
                text = value
                textSize = size
                setTextColor(color)
                if (bold) typeface = Typeface.DEFAULT_BOLD
                setPadding(0, 7, 0, 7)
            }

        root.addView(label("ES NEWS • AI NEWS DESK", 23f, Color.rgb(255, 209, 102), true))
        root.addView(label("TALKING NEWS ANCHOR • DEMO", 13f, Color.LTGRAY, true))

        val studio = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(12, 12, 12, 12)
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(13, 43, 82), Color.rgb(22, 78, 112), Color.rgb(10, 22, 39))
            ).apply { cornerRadius = 18f }
        }
        studio.addView(label("🔴 LIVE  |  ES NEWS", 18f, Color.rgb(255, 95, 95), true).apply {
            gravity = Gravity.CENTER
        })

        avatar = AnchorView(this)
        studio.addView(avatar, LinearLayout.LayoutParams(-1, 300))
        studio.addView(TextView(this).apply {
            text = "ES NEWS  •  বাংলা সংবাদ"
            textSize = 19f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            setPadding(8, 12, 8, 12)
            background = rounded(Color.rgb(23, 54, 93), 10f)
        }, LinearLayout.LayoutParams(-1, -2))
        root.addView(studio, LinearLayout.LayoutParams(-1, -2).apply {
            setMargins(0, 12, 0, 12)
        })

        root.addView(TextView(this).apply {
            text = "BREAKING NEWS  |  আপনার এলাকার সর্বশেষ খবর"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            setPadding(12, 12, 12, 12)
            background = rounded(Color.rgb(183, 28, 28), 8f)
        })

        root.addView(label("অ্যাঙ্কার নির্বাচন করুন", 18f))
        genderPicker = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                listOf("পুরুষ অ্যাঙ্কার", "মহিলা অ্যাঙ্কার")
            )
            onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                    avatar.female = position == 1
                    avatar.invalidate()
                }
            }
        }
        root.addView(genderPicker)

        root.addView(label("বাংলা নিউজ স্ক্রিপ্ট লিখুন", 18f))
        script = EditText(this).apply {
            hint = "এখানে খবরের স্ক্রিপ্ট লিখুন বা পেস্ট করুন..."
            setHintTextColor(Color.LTGRAY)
            setTextColor(Color.WHITE)
            textSize = 17f
            minLines = 5
            gravity = Gravity.TOP
            setPadding(14, 14, 14, 14)
            background = rounded(Color.rgb(36, 50, 68), 10f)
        }
        root.addView(script, LinearLayout.LayoutParams(-1, -2))

        root.addView(Button(this).apply {
            text = "▶ বাংলা ভয়েসে খবর পড়ুন"
            setOnClickListener {
                val text = script.text.toString().trim()
                when {
                    text.isEmpty() -> status.text = "আগে বাংলা নিউজ স্ক্রিপ্ট লিখুন।"
                    !ready -> status.text = "ভয়েস প্রস্তুত হচ্ছে। একটু পরে আবার চেষ্টা করুন।"
                    else -> {
                        val language = tts?.setLanguage(Locale("bn", "IN"))
                        if (language == TextToSpeech.LANG_MISSING_DATA ||
                            language == TextToSpeech.LANG_NOT_SUPPORTED) {
                            status.text = "ফোনে বাংলা TTS voice নেই। Text-to-Speech সেটিংসে Bengali voice ইনস্টল করুন।"
                        } else {
                            avatar.talking = true
                            avatar.startMouthAnimation()
                            status.text = "ES NEWS অ্যাঙ্কার খবর পড়ছে..."
                            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "es_news_story")
                        }
                    }
                }
            }
        })

        root.addView(Button(this).apply {
            text = "■ ভয়েস বন্ধ করুন"
            setOnClickListener {
                tts?.stop()
                avatar.stopMouthAnimation()
                status.text = "ভয়েস বন্ধ করা হয়েছে।"
            }
        })

        status = label("স্টুডিও প্রস্তুত। স্ক্রিপ্ট লিখে ভয়েস চালু করুন।", 14f, Color.rgb(255, 209, 102))
        root.addView(status)
        root.addView(label(
            "নোট: এই ডেমোতে অ্যাঙ্কারের মুখের অ্যানিমেশন ভয়েস চলার সময় নড়বে। এটি 3D মডেল বা শব্দ-অনুযায়ী নিখুঁত Lip Sync নয়।",
            12f, Color.LTGRAY
        ))
        setContentView(scroll)
    }

    override fun onInit(result: Int) {
        ready = result == TextToSpeech.SUCCESS
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                runOnUiThread {
                    avatar.talking = true
                    avatar.startMouthAnimation()
                    status.text = "ES NEWS অ্যাঙ্কার খবর পড়ছে..."
                }
            }
            override fun onDone(utteranceId: String?) {
                runOnUiThread {
                    avatar.stopMouthAnimation()
                    status.text = "খবর পড়া শেষ।"
                }
            }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                runOnUiThread {
                    avatar.stopMouthAnimation()
                    status.text = "ভয়েস চালাতে সমস্যা হয়েছে।"
                }
            }
        })
    }

    override fun onDestroy() {
        avatarOrNullStop()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    private fun avatarOrNullStop() {
        if (::avatar.isInitialized) avatar.stopMouthAnimation()
    }

    class AnchorView(context: android.content.Context) : View(context) {
        var female = false
        var talking = false
        private var mouthOpen = false
        private val handler = Handler(Looper.getMainLooper())
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        private val animate = object : Runnable {
            override fun run() {
                if (!talking) return
                mouthOpen = !mouthOpen
                invalidate()
                handler.postDelayed(this, 170)
            }
        }

        fun startMouthAnimation() {
            talking = true
            handler.removeCallbacks(animate)
            handler.post(animate)
        }

        fun stopMouthAnimation() {
            talking = false
            mouthOpen = false
            handler.removeCallbacks(animate)
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat()
            val h = height.toFloat()
            canvas.drawColor(Color.TRANSPARENT)

            val cx = w / 2f
            val headY = h * 0.43f
            val scale = minOf(w / 340f, h / 300f, 1.2f)
            canvas.save()
            canvas.translate(cx, headY)
            canvas.scale(scale, scale)

            // shoulders and suit
            paint.color = Color.rgb(20, 43, 75)
            canvas.drawRoundRect(-105f, 55f, 105f, 190f, 32f, 32f, paint)
            paint.color = Color.WHITE
            val shirt = Path().apply {
                moveTo(-34f, 58f); lineTo(0f, 105f); lineTo(34f, 58f); close()
            }
            canvas.drawPath(shirt, paint)
            paint.color = Color.rgb(190, 35, 45)
            val tie = Path().apply {
                moveTo(-9f, 75f); lineTo(9f, 75f); lineTo(13f, 145f); lineTo(0f, 158f); lineTo(-13f, 145f); close()
            }
            canvas.drawPath(tie, paint)

            // neck and head
            paint.color = Color.rgb(220, 166, 125)
            canvas.drawRoundRect(-22f, 34f, 22f, 83f, 10f, 10f, paint)
            paint.color = if (female) Color.rgb(45, 30, 27) else Color.rgb(48, 35, 30)
            canvas.drawOval(RectF(-59f, -100f, 59f, 65f), paint)
            paint.color = Color.rgb(238, 190, 151)
            canvas.drawOval(RectF(-49f, -91f, 49f, 54f), paint)

            // hair fringe
            paint.color = if (female) Color.rgb(42, 26, 24) else Color.rgb(40, 30, 27)
            canvas.drawArc(RectF(-51f, -100f, 51f, -18f), 180f, 180f, true, paint)
            if (female) {
                canvas.drawRoundRect(-57f, -70f, -42f, 92f, 12f, 12f, paint)
                canvas.drawRoundRect(42f, -70f, 57f, 92f, 12f, 12f, paint)
            }

            // eyes and brows
            paint.color = Color.rgb(45, 35, 30)
            canvas.drawCircle(-19f, -28f, 4f, paint)
            canvas.drawCircle(19f, -28f, 4f, paint)
            paint.strokeWidth = 3f
            canvas.drawLine(-28f, -40f, -12f, -42f, paint)
            canvas.drawLine(12f, -42f, 28f, -40f, paint)

            // nose
            paint.strokeWidth = 2f
            canvas.drawLine(0f, -22f, -3f, -4f, paint)

            // mouth, animated while TTS is speaking
            paint.color = Color.rgb(115, 35, 42)
            if (mouthOpen) {
                canvas.drawOval(RectF(-13f, 14f, 13f, 35f), paint)
            } else {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 3.5f
                canvas.drawArc(RectF(-14f, 10f, 14f, 33f), 15f, 150f, false, paint)
                paint.style = Paint.Style.FILL
            }

            // studio microphone
            paint.color = Color.rgb(185, 211, 220)
            canvas.drawRoundRect(-9f, -178f, 9f, -126f, 9f, 9f, paint)
            paint.color = Color.rgb(65, 89, 105)
            for (i in 0..4) canvas.drawLine(-5f, -170f + i * 8, 5f, -170f + i * 8, paint)
            paint.strokeWidth = 4f
            paint.style = Paint.Style.STROKE
            canvas.drawArc(RectF(-18f, -184f, 18f, -125f), 0f, 180f, false, paint)
            canvas.drawLine(0f, -125f, 0f, -112f, paint)
            paint.style = Paint.Style.FILL

            canvas.restore()
            paint.color = Color.WHITE
            paint.textAlign = Paint.Align.CENTER
            paint.textSize = 17f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText(if (talking) "ANCHOR • ON AIR" else "ES NEWS ANCHOR", cx, h - 10f, paint)
        }
    }
}
