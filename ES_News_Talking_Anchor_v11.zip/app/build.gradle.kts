plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.aivideostudio.mobile"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.aivideostudio.mobile"
        minSdk = 26
        targetSdk = 35
        versionCode = 11
        versionName = "11.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
