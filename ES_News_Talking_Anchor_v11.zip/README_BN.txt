ES NEWS Talking Anchor v4

এই সংস্করণে পুরুষ/মহিলা অ্যাঙ্কার নির্বাচন, বাংলা TTS এবং TTS চলার সময় মুখের সাধারণ অ্যানিমেশন আছে।
এটি হাতে আঁকা 2D স্টাইলের ডেমো; বাস্তব 3D মডেল, phoneme-based lip sync বা MP4 export নয়।

Build:
GitHub Actions workflow থেকে ZIP extract করে app:assembleDebug চালাতে হবে।
