package com.aivideostudio.mobile

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private var imageCount = 0
    private lateinit var countLabel: TextView
    private lateinit var status: TextView
    private lateinit var prompt: EditText

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 30, 24, 24)
            setBackgroundColor(0xFF171522.toInt())
        }

        fun label(text: String, size: Float = 16f) = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 10, 0, 10)
        }

        val title = label("AI Video Studio", 27f)
        val subtitle = label("Mobile Video Creator • 720p / 1080p", 14f)

        prompt = EditText(this).apply {
            hint = "ভিডিওর বিষয় বা AI prompt লিখুন"
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFFB8B5C7.toInt())
            setPadding(14, 12, 14, 12)
            setBackgroundColor(0xFF302D40.toInt())
        }

        val addImages = Button(this).apply {
            text = "গ্যালারি থেকে ছবি যোগ করুন"
            setOnClickListener {
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "image/*"
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                }
                @Suppress("DEPRECATION")
                startActivityForResult(Intent.createChooser(intent, "ছবি নির্বাচন করুন"), 101)
            }
        }

        countLabel = label("নির্বাচিত ছবি: 0")
        val resolution = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                listOf("720p", "1080p")
            )
        }
        status = label("শুরু করতে গ্যালারি থেকে ছবি যোগ করুন।", 14f)

        val export = Button(this).apply {
            text = "ভিডিও তৈরি / Export"
            setOnClickListener {
                status.text = if (imageCount == 0) {
                    "প্রথমে গ্যালারি থেকে ছবি যোগ করুন।"
                } else {
                    "ছবি নির্বাচন হয়েছে। এই Starter সংস্করণে MP4 Export ও AI generation এখনও যুক্ত নয়।"
                }
            }
        }

        val note = label(
            "প্রাথমিক Starter App: ছবি নির্বাচন ও অ্যাপের UI প্রস্তুত। MP4 Export, AI ভিডিও, ভয়েসওভার ও মিউজিক পরবর্তী উন্নয়নের কাজ।",
            12f
        )

        listOf(title, subtitle, prompt, addImages, countLabel, resolution, export, status, note).forEach {
            root.addView(it, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 10 })
        }

        setContentView(ScrollView(this).apply { addView(root) })
    }

    @Deprecated("Legacy picker callback for Android compatibility")
    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 101 && resultCode == RESULT_OK && data != null) {
            imageCount = data.clipData?.itemCount ?: if (data.data != null) 1 else 0
            countLabel.text = "নির্বাচিত ছবি: $imageCount"
            status.text = if (imageCount > 0) "ছবি যোগ হয়েছে।" else "কোনও ছবি নির্বাচন করা হয়নি।"
        }
    }
}
