package com.aivideostudio.mobile

import android.app.Activity
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.*
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ready = false
    private lateinit var script: EditText
    private lateinit var status: TextView
    private lateinit var avatar: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 24)
            setBackgroundColor(0xFF101827.toInt())
        }
        val scroll = ScrollView(this)
        scroll.addView(root)

        fun label(s: String, size: Float, color: Int = 0xFFFFFFFF.toInt()) =
            TextView(this).apply {
                text = s
                textSize = size
                setTextColor(color)
                setPadding(0, 8, 0, 8)
            }

        root.addView(label("AI Video Studio", 27f))
        root.addView(label("3D-Style AI News Anchor • Demo", 15f, 0xFF9FB7D9.toInt()))

        avatar = label("🎙️\n👨🏻‍💼\n\nES NEWS", 34f).apply {
            gravity = Gravity.CENTER
            setBackgroundColor(0xFF243B5A.toInt())
        }
        root.addView(avatar, LinearLayout.LayoutParams(-1, 260).apply {
            setMargins(0, 16, 0, 16)
        })

        root.addView(label("অ্যাঙ্কার নির্বাচন করুন", 17f))
        val picker = Spinner(this)
        picker.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            listOf("পুরুষ 3D-স্টাইল অ্যাঙ্কার", "মহিলা 3D-স্টাইল অ্যাঙ্কার")
        )
        picker.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                avatar.text = if (position == 0) "🎙️\n👨🏻‍💼\n\nES NEWS" else "🎙️\n👩🏻‍💼\n\nES NEWS"
            }
        }
        root.addView(picker)

        root.addView(label("বাংলা নিউজ স্ক্রিপ্ট লিখুন", 17f))
        script = EditText(this).apply {
            hint = "এখানে খবরের স্ক্রিপ্ট লিখুন বা পেস্ট করুন..."
            setHintTextColor(0xFF9AA8BA.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 17f
            minLines = 6
            gravity = Gravity.TOP
            setPadding(14, 14, 14, 14)
            setBackgroundColor(0xFF243244.toInt())
        }
        root.addView(script)

        val speak = Button(this).apply {
            text = "▶ বাংলা ভয়েসে খবর পড়ুন"
            setOnClickListener {
                val value = script.text.toString().trim()
                when {
                    value.isEmpty() -> status.text = "আগে বাংলা নিউজ স্ক্রিপ্ট লিখুন।"
                    !ready -> status.text = "ভয়েস প্রস্তুত হচ্ছে। একটু পরে আবার চাপুন।"
                    else -> {
                        val lang = tts?.setLanguage(Locale("bn", "IN"))
                        if (lang == TextToSpeech.LANG_MISSING_DATA || lang == TextToSpeech.LANG_NOT_SUPPORTED) {
                            status.text = "ফোনে বাংলা TTS voice নেই। Text-to-Speech সেটিংসে Bengali voice ইনস্টল করুন।"
                        } else {
                            tts?.speak(value, TextToSpeech.QUEUE_FLUSH, null, "news_script")
                            status.text = "অ্যাঙ্কার এখন স্ক্রিপ্ট পড়ছে। এটি ভয়েস ডেমো; MP4 এখনো তৈরি করে না।"
                        }
                    }
                }
            }
        }
        root.addView(speak)
        root.addView(Button(this).apply {
            text = "■ ভয়েস বন্ধ করুন"
            setOnClickListener { tts?.stop(); status.text = "ভয়েস বন্ধ করা হয়েছে।" }
        })

        status = label("ডেমো প্রস্তুত। স্ক্রিপ্ট লিখে ভয়েস চালু করুন।", 14f, 0xFFFFD27A.toInt())
        root.addView(status)
        root.addView(label(
            "নোট: এটি 3D-স্টাইল স্ক্রিন ও ফোনের Text-to-Speech-এর প্রাথমিক ডেমো। বাস্তব 3D মুখের নড়াচড়া, AI Lip Sync এবং MP4 Export এখনো যুক্ত হয়নি।",
            12f, 0xFFB8C5D6.toInt()
        ))
        setContentView(scroll)
    }

    override fun onInit(result: Int) {
        ready = result == TextToSpeech.SUCCESS
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
