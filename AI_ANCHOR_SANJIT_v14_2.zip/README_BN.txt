AI ANCHOR SANJIT v14.1 — video playback fix

Workflow copies the MP4 into:
app/src/main/assets/videos/standing_anchor.mp4

MainActivity copies this asset to the app cache, then plays the cached file
with Android VideoView. This avoids attempting to play file:///android_asset
directly, which can cause a black screen on some devices.

Includes Bengali TTS, pitch/speed controls, script input and looping video.
Lip-sync and MP4 export are not included in this version.
