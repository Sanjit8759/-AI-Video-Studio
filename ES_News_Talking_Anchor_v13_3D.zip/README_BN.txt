ES NEWS Talking Anchor v13

এই সংস্করণে:
- ব্যবহারকারীর দেওয়া model.glb ফাইল Android অ্যাপে যুক্ত করা হয়েছে।
- পুরুষ অ্যাঙ্কার Three.js WebView-তে 3D হিসেবে দেখানো হয়।
- ফোনের Android Bengali Text-to-Speech আগের মতোই ব্যবহৃত হয়।
- TTS চলার সময় সাধারণ মুখের morph animation ও হালকা idle movement চালু হয়।
- মহিলা অ্যাঙ্কারের পুরোনো ডেমো ভিউ রাখা হয়েছে।

গুরুত্বপূর্ণ:
- 3D মডেল লোড করতে প্রথমবার ইন্টারনেট দরকার (Three.js CDN থেকে)।
- Morph target-এর সঠিক নাম/ক্রম GLB-তে সংরক্ষিত নেই; তাই বর্তমান মুখের অ্যানিমেশন পরীক্ষামূলক, নিখুঁত বাংলা phoneme lip-sync নয়।
- GLB-তে আগে থেকে body animation clip নেই; বর্তমান idle movement হালকা procedural movement।
- Android Studio প্রয়োজন নেই।

GitHub Actions:
1. ZIP extract করে GitHub repository-র main branch-এ সব ফাইল upload করুন।
2. Commit changes করুন।
3. Actions > Build ES NEWS Android APK চালান।
4. সফল হলে ES-NEWS-3D-Anchor-APK artifact download করুন।
