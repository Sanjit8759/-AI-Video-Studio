package com.aivideostudio.mobile

import android.app.Activity
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.*
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ready = false
    private lateinit var script: EditText
    private lateinit var status: TextView
    private lateinit var avatar: TextView
    private lateinit var genderPicker: Spinner

    private fun panel(color: Int, radius: Float = 14f): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 20, 18, 22)
            setBackgroundColor(0xFF0B1220.toInt())
        }
        val scroll = ScrollView(this)
        scroll.addView(root)

        fun label(value: String, size: Float, color: Int = 0xFFFFFFFF.toInt(), bold: Boolean = false) =
            TextView(this).apply {
                text = value
                textSize = size
                setTextColor(color)
                if (bold) typeface = Typeface.DEFAULT_BOLD
                setPadding(0, 7, 0, 7)
            }

        root.addView(label("AI Video Studio", 27f, 0xFFFFFFFF.toInt(), true))
        root.addView(label("ES NEWS • AI NEWS DESK", 14f, 0xFFFFD166.toInt(), true))

        val studio = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(14, 18, 14, 18)
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF102A56.toInt(), 0xFF174C72.toInt(), 0xFF101827.toInt())
            ).apply { cornerRadius = 18f }
        }

        val topLine = TextView(this).apply {
            text = "● LIVE  |  ES NEWS"
            textSize = 17f
            setTextColor(0xFFFF5252.toInt())
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        studio.addView(topLine)

        avatar = TextView(this).apply {
            text = "🎙️\n👨🏻‍💼\n\nNEWS ANCHOR"
            textSize = 34f
            setTextColor(0xFFFFFFFF.toInt())
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(10, 16, 10, 16)
        }
        studio.addView(avatar, LinearLayout.LayoutParams(-1, 205))

        val desk = TextView(this).apply {
            text = "ES NEWS  •  বাংলা সংবাদ"
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setPadding(10, 12, 10, 12)
            background = panel(0xFF17365D.toInt(), 10f)
        }
        studio.addView(desk, LinearLayout.LayoutParams(-1, -2))
        root.addView(studio, LinearLayout.LayoutParams(-1, -2).apply {
            setMargins(0, 12, 0, 14)
        })

        val ticker = TextView(this).apply {
            text = "BREAKING NEWS  |  আপনার এলাকার সর্বশেষ খবর"
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(12, 12, 12, 12)
            background = panel(0xFFB71C1C.toInt(), 8f)
        }
        root.addView(ticker)

        root.addView(label("অ্যাঙ্কার নির্বাচন করুন", 17f))
        genderPicker = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                listOf("পুরুষ 3D-স্টাইল অ্যাঙ্কার", "মহিলা 3D-স্টাইল অ্যাঙ্কার")
            )
            onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                    avatar.text = if (position == 0) "🎙️\n👨🏻‍💼\n\nNEWS ANCHOR" else "🎙️\n👩🏻‍💼\n\nNEWS ANCHOR"
                }
            }
        }
        root.addView(genderPicker)

        root.addView(label("বাংলা নিউজ স্ক্রিপ্ট লিখুন", 17f))
        script = EditText(this).apply {
            hint = "এখানে খবরের স্ক্রিপ্ট লিখুন বা পেস্ট করুন..."
            setHintTextColor(0xFF9AA8BA.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 17f
            minLines = 6
            gravity = Gravity.TOP
            setPadding(14, 14, 14, 14)
            background = panel(0xFF243244.toInt(), 10f)
        }
        root.addView(script, LinearLayout.LayoutParams(-1, -2))

        root.addView(Button(this).apply {
            text = "▶ বাংলা ভয়েসে খবর পড়ুন"
            setOnClickListener {
                val value = script.text.toString().trim()
                when {
                    value.isEmpty() -> status.text = "আগে বাংলা নিউজ স্ক্রিপ্ট লিখুন।"
                    !ready -> status.text = "ভয়েস প্রস্তুত হচ্ছে। একটু পরে আবার চাপুন।"
                    else -> {
                        val lang = tts?.setLanguage(Locale("bn", "IN"))
                        if (lang == TextToSpeech.LANG_MISSING_DATA || lang == TextToSpeech.LANG_NOT_SUPPORTED) {
                            status.text = "ফোনে বাংলা TTS voice নেই। Text-to-Speech সেটিংসে Bengali voice ইনস্টল করুন।"
                        } else {
                            tts?.speak(value, TextToSpeech.QUEUE_FLUSH, null, "news_script")
                            status.text = "ES NEWS স্টুডিও ডেমোতে অ্যাঙ্কার স্ক্রিপ্ট পড়ছে।"
                        }
                    }
                }
            }
        })

        root.addView(Button(this).apply {
            text = "■ ভয়েস বন্ধ করুন"
            setOnClickListener { tts?.stop(); status.text = "ভয়েস বন্ধ করা হয়েছে।" }
        })

        status = label("স্টুডিও ডেমো প্রস্তুত। স্ক্রিপ্ট লিখে ভয়েস চালু করুন।", 14f, 0xFFFFD166.toInt())
        root.addView(status)
        root.addView(label(
            "নোট: এই সংস্করণে ES NEWS-স্টাইল স্টুডিও ব্যাকগ্রাউন্ড, অ্যাঙ্কার নির্বাচন ও ফোনের বাংলা Text-to-Speech রয়েছে। এটি প্রকৃত 3D মডেল, Lip Sync বা MP4 Export নয়; সেগুলো পরবর্তী উন্নয়ন।",
            12f, 0xFFB8C5D6.toInt()
        ))
        setContentView(scroll)
    }

    override fun onInit(result: Int) {
        ready = result == TextToSpeech.SUCCESS
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
