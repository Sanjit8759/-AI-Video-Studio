plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.aivideostudio.mobile"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.aivideostudio.mobile"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
