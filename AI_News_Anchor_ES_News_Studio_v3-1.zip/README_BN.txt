AI Video Studio – Cloud Build Starter

এই ZIP-এ Android Studio ছাড়াই GitHub Actions দিয়ে APK build করার workflow রাখা হয়েছে।

ফোন থেকে:
1. ZIP Extract করে ফোল্ডারের সব ফাইল GitHub repository-তে upload করুন।
2. GitHub repository-র Actions tab খুলুন।
3. Build Android APK workflow নির্বাচন করুন।
4. Run workflow চাপুন।
5. Build সফল হলে workflow run-এর নিচে Artifacts থেকে AI-Video-Studio-debug-apk.zip ডাউনলোড করুন।
6. ZIP Extract করে app-debug.apk ফোনে ইনস্টল করুন। Android চাইলে browser/file manager-এর জন্য Install unknown apps অনুমতি দিন।

গুরুত্বপূর্ণ:
- এটি একটি প্রাথমিক Starter APK, সম্পূর্ণ AI Video Editor নয়।
- বর্তমান সংস্করণে অ্যাপের UI ও ছবি নির্বাচন আছে।
- MP4 rendering/export, timeline, বাংলা/হিন্দি voice-over, music editing এবং online AI video generation এখনও যুক্ত হয়নি।
- Online AI generation-এর জন্য পরবর্তীতে নিরাপদ backend/API প্রয়োজন হবে।
