package com.aianchorsanjit.app

import android.app.Activity
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.widget.*
import android.graphics.Color
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private lateinit var playerView: PlayerView
    private lateinit var script: EditText
    private lateinit var status: TextView
    private lateinit var pitchLabel: TextView
    private lateinit var speedLabel: TextView

    private var player: ExoPlayer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    private var pitchValue = 1.0f
    private var speedValue = 1.0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        buildScreen()
        tts = TextToSpeech(this, this)
        prepareAnchorVideo()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 18, 16, 16)
            setBackgroundColor(Color.rgb(7, 17, 32))
        }

        root.addView(TextView(this).apply {
            text = "AI ANCHOR SANJIT"
            textSize = 27f
            setTextColor(Color.rgb(245, 198, 85))
            gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
        })

        root.addView(TextView(this).apply {
            text = "POWERED BY ES NEWS"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 10)
        })

        playerView = PlayerView(this).apply {
            setBackgroundColor(Color.BLACK)
            useController = false
        }

        root.addView(
            playerView,
            LinearLayout.LayoutParams(-1, 0, 1.1f)
        )

        status = TextView(this).apply {
            text = "স্টুডিও প্রস্তুত"
            textSize = 14f
            setTextColor(Color.rgb(245, 198, 85))
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 8)
        }
        root.addView(status)

        root.addView(TextView(this).apply {
            text = "বাংলা নিউজ স্ক্রিপ্ট লিখুন"
            textSize = 19f
            setTextColor(Color.WHITE)
        })

        script = EditText(this).apply {
            hint = "এখানে খবরের স্ক্রিপ্ট লিখুন বা পেস্ট করুন..."
            textSize = 17f
            minLines = 4
            gravity = Gravity.TOP or Gravity.START
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            setPadding(12, 12, 12, 12)
            setBackgroundColor(Color.rgb(35, 49, 68))
        }

        root.addView(
            script,
            LinearLayout.LayoutParams(-1, 0, 0.8f)
        )

        pitchLabel = makeLabel("কণ্ঠের Pitch: 1.00")
        root.addView(pitchLabel)

        root.addView(SeekBar(this).apply {
            max = 150
            progress = 50
            setOnSeekBarChangeListener(makeListener { value ->
                pitchValue = 0.5f + value / 100f
                pitchLabel.text = "কণ্ঠের Pitch: %.2f".format(pitchValue)
            })
        })

        speedLabel = makeLabel("কথার গতি: 1.00")
        root.addView(speedLabel)

        root.addView(SeekBar(this).apply {
            max = 150
            progress = 50
            setOnSeekBarChangeListener(makeListener { value ->
                speedValue = 0.5f + value / 100f
                speedLabel.text = "কথার গতি: %.2f".format(speedValue)
            })
        })

        root.addView(Button(this).apply {
            text = "▶ বাংলা ভয়েসে খবর পড়ুন"
            setOnClickListener {
                speakNews()
            }
        })

        root.addView(Button(this).apply {
            text = "■ ভয়েস ও ভিডিও বন্ধ করুন"
            setOnClickListener {
                stopNews()
            }
        })

        setContentView(root)
    }

    private fun makeLabel(value: String): TextView {
        return TextView(this).apply {
            text = value
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(0, 8, 0, 2)
        }
    }

    private fun makeListener(
        update: (Int) -> Unit
    ): SeekBar.OnSeekBarChangeListener {
        return object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(
                bar: SeekBar?,
                value: Int,
                fromUser: Boolean
            ) {
                update(value)
            }

            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        }
    }

    private fun prepareAnchorVideo() {
        try {
            status.text = "অ্যাঙ্কার ভিডিও প্রস্তুত হচ্ছে..."

            val videoFile = File(cacheDir, "standing_anchor.mp4")

            assets.open("videos/standing_anchor.mp4").use { input ->
                FileOutputStream(videoFile).use { output ->
                    input.copyTo(output)
                }
            }

            val exo = ExoPlayer.Builder(this).build()
            player = exo
            playerView.player = exo

            exo.volume = 0f
            exo.repeatMode = Player.REPEAT_MODE_ONE

            exo.setMediaItem(
                MediaItem.fromUri(videoFile.toURI().toString())
            )

            exo.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(playbackState: Int) {
                    if (playbackState == Player.STATE_READY) {
                        status.text = "স্টুডিও প্রস্তুত"
                    }
                }

                override fun onPlayerError(
                    error: androidx.media3.common.PlaybackException
                ) {
                    status.text = "ভিডিও সমস্যা: ${error.message}"
                }
            })

            exo.prepare()

            // অ্যাপ খুললে ভিডিও চলবে না
            exo.playWhenReady = false

        } catch (e: Exception) {
            status.text = "ভিডিও ফাইল পাওয়া যায়নি: ${e.message}"
        }
    }

    private fun speakNews() {
        val news = script.text.toString().trim()

        if (news.isEmpty()) {
            status.text = "আগে বাংলা নিউজ স্ক্রিপ্ট লিখুন"
            return
        }

        if (!ttsReady) {
            status.text = "বাংলা ভয়েস প্রস্তুত হচ্ছে"
            return
        }

        val exo = player
        if (exo == null || exo.playbackState == Player.STATE_IDLE) {
            status.text = "ভিডিও প্রস্তুত হয়নি"
            return
        }

        tts?.stop()

        exo.seekTo(0)
        exo.play()

        tts?.setPitch(pitchValue)
        tts?.setSpeechRate(speedValue)

        val result = tts?.speak(
            news,
            TextToSpeech.QUEUE_FLUSH,
            Bundle(),
            "ES_NEWS_SCRIPT"
        )

        if (result == TextToSpeech.ERROR) {
            exo.pause()
            exo.seekTo(0)
            status.text = "ভয়েস চালু করা যায়নি"
        } else {
            status.text = "অ্যাঙ্কার নিউজ পড়ছে"
        }
    }

    private fun stopNews() {
        tts?.stop()
        player?.pause()
        player?.seekTo(0)
        status.text = "ভয়েস ও ভিডিও বন্ধ"
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) {
            val languageResult = tts?.setLanguage(Locale("bn", "IN"))

            ttsReady =
                languageResult != TextToSpeech.LANG_MISSING_DATA &&
                languageResult != TextToSpeech.LANG_NOT_SUPPORTED

            tts?.setOnUtteranceProgressListener(
                object : UtteranceProgressListener() {

                    override fun onStart(utteranceId: String?) {}

                    override fun onDone(utteranceId: String?) {
                        runOnUiThread {
                            if (utteranceId == "ES_NEWS_SCRIPT") {
                                player?.pause()
                                player?.seekTo(0)
                                status.text = "নিউজ পড়া শেষ"
                            }
                        }
                    }

                    override fun onError(utteranceId: String?) {
                        runOnUiThread {
                            player?.pause()
                            status.text = "ভয়েসে সমস্যা হয়েছে"
                        }
                    }
                }
            )

            runOnUiThread {
                if (::status.isInitialized) {
                    status.text =
                        if (ttsReady) "বাংলা ভয়েস প্রস্তুত"
                        else "ফোনে বাংলা TTS ভয়েস নেই"
                }
            }
        }
    }

    override fun onDestroy() {
        if (::playerView.isInitialized) {
            playerView.player = null
        }

        player?.release()
        player = null

        tts?.stop()
        tts?.shutdown()

        super.onDestroy()
    }
}